Nion Swift Experimental
=======================

A Nion Swift package for experimental menu items and scripts.

.. start-badges

.. list-table::
    :stub-columns: 1

    * - tests
      - | |linux|
    * - package
      - |version|


.. |linux| image:: https://img.shields.io/travis/nion-software/experimental/master.svg?label=Linux%20build
   :target: https://travis-ci.org/nion-software/experimental
   :alt: Travis CI build status (Linux)

.. |version| image:: https://img.shields.io/pypi/v/nionswift-experimental.svg
   :target: https://pypi.org/project/nionswift-experimental/
   :alt: Latest PyPI version

.. end-badges

More Information
----------------

- `Changelog <https://github.com/nion-software/experimental/blob/master/CHANGES.rst>`_
